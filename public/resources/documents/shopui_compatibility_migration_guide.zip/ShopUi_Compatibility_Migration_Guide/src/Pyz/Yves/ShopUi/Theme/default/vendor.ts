// add webcomponents polyfill
import '@webcomponents/webcomponentsjs/webcomponents-bundle';
