import { bootstrap } from 'ShopUi/app';
bootstrap();
